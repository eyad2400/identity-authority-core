from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, make_response, request, send_from_directory


BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"
DB_PATH = BASE_DIR / "roster.db"


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                data TEXT NOT NULL,
                version INTEGER NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        row = conn.execute("SELECT COUNT(*) AS count FROM state WHERE id = 1").fetchone()
        if row["count"] == 0:
            empty_state = {
                "officers": [],
                "officerLimits": {},
                "departments": [],
                "jobTitles": [],
                "duties": [],
                "ranks": [],
                "roster": {},
                "archivedRoster": {},
                "exceptions": [],
                "supportRequests": [],
                "activityLog": [],
                "settings": {},
            }
            conn.execute(
                "INSERT INTO state (id, data, version, updated_at) VALUES (1, ?, 1, ?)",
                (json.dumps(empty_state, ensure_ascii=False), datetime.utcnow().isoformat()),
            )


app = Flask(__name__, static_folder=None)
init_db()


@app.after_request
def add_no_store(response):
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/api/state")
def get_state():
    with get_db() as conn:
        row = conn.execute("SELECT data, version FROM state WHERE id = 1").fetchone()
        if row is None:
            return jsonify({"state": {}, "version": 0})
        response = jsonify({"state": json.loads(row["data"]), "version": row["version"]})
        response.headers["ETag"] = str(row["version"])
        return response


@app.put("/api/state")
def put_state():
    payload = request.get_json(silent=True) or {}
    state = payload.get("state")
    if state is None:
        return make_response(jsonify({"error": "missing state"}), 400)

    if_match = request.headers.get("If-Match")
    if if_match is None:
        return make_response(jsonify({"error": "missing If-Match version"}), 428)

    with get_db() as conn:
        row = conn.execute("SELECT version FROM state WHERE id = 1").fetchone()
        current_version = row["version"] if row else 0
        if str(current_version) != str(if_match):
            return make_response(
                jsonify({"error": "version conflict", "version": current_version}), 409
            )
        new_version = current_version + 1
        conn.execute(
            "UPDATE state SET data = ?, version = ?, updated_at = ? WHERE id = 1",
            (json.dumps(state, ensure_ascii=False), new_version, datetime.utcnow().isoformat()),
        )
    response = jsonify({"version": new_version})
    response.headers["ETag"] = str(new_version)
    return response


@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.get("/<path:filename>")
def static_files(filename: str):
    return send_from_directory(FRONTEND_DIR, filename)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)